import { useState } from 'react'
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from 'recharts'

// ─── Types ───────────────────────────────────────────────────────────────────

type Tab = 'projetos' | 'indicadores' | 'pessoas'
type Squad = 'todos' | 'alpha' | 'beta' | 'gamma' | 'delta'
type ProjectStatus = 'saudavel' | 'atencao' | 'critico'
type IncidentType = 'operacional' | 'estrutural'
type Criticality = 'alta' | 'media' | 'baixa'

// ─── Data ────────────────────────────────────────────────────────────────────

const squads: { id: Squad; label: string }[] = [
  { id: 'todos', label: 'Todos os Squads' },
  { id: 'alpha', label: 'Squad Alpha' },
  { id: 'beta', label: 'Squad Beta' },
  { id: 'gamma', label: 'Squad Gamma' },
  { id: 'delta', label: 'Squad Delta' },
]

interface Project {
  name: string
  techLead: string
  squad: Squad
  status: ProjectStatus
  features: number
  leadTime: string
  summary: string
  nextDecision: string
  statusNote: string
}

const projects: Project[] = [
  {
    name: 'Plataforma de Pagamentos v3',
    techLead: 'Renata Souza',
    squad: 'alpha',
    status: 'saudavel',
    features: 6,
    leadTime: '3.2 dias',
    summary: 'Migração do gateway legado concluída em 80%. Integração com PSP secundário em progresso.',
    nextDecision: 'Aprovar rollout gradual para 20% dos usuários na sexta.',
    statusNote: 'Lead time dentro do SLA. FTR em 94%.',
  },
  {
    name: 'Data Mesh — Camada Semântica',
    techLead: 'Felipe Andrade',
    squad: 'beta',
    status: 'atencao',
    features: 4,
    leadTime: '7.8 dias',
    summary: 'Bloqueio em definição de ownership dos domínios de dados. Dependência de times externos.',
    nextDecision: 'Escalar alinhamento com Produto e Dados até quarta-feira.',
    statusNote: 'Lead time acima do P50. FTR caiu para 71%.',
  },
  {
    name: 'Auth & IAM — Zero Trust',
    techLead: 'Camila Torres',
    squad: 'alpha',
    status: 'critico',
    features: 9,
    leadTime: '14.1 dias',
    summary: 'Escopo expandiu sem revisão de capacidade. 3 features em WIP há mais de 10 dias.',
    nextDecision: 'Revisão de WIP limit e replanning de sprint urgente.',
    statusNote: 'Lead time crítico. FTR em 58%. Atenção redobrada.',
  },
  {
    name: 'Catálogo de Produtos — Search',
    techLead: 'Lucas Meirelles',
    squad: 'gamma',
    status: 'saudavel',
    features: 3,
    leadTime: '2.9 dias',
    summary: 'Motor de busca com ranking semântico em produção. A/B test com uplift de 12% em conversão.',
    nextDecision: 'Encerrar experimento e promover variante vencedora.',
    statusNote: 'Lead time excelente. FTR em 97%.',
  },
  {
    name: 'Observabilidade & SRE Platform',
    techLead: 'Ana Beatriz Lima',
    squad: 'delta',
    status: 'atencao',
    features: 5,
    leadTime: '6.4 dias',
    summary: 'Dashboards de golden signals entregues. Alerting ainda manual em 40% dos serviços.',
    nextDecision: 'Definir meta de cobertura de alertas para Q3.',
    statusNote: 'Lead time estável mas FTR em 76%.',
  },
]

interface Incident {
  title: string
  type: IncidentType
  criticality: Criticality
  description: string
  action: string
  squad: Squad
}

const incidents: Incident[] = [
  {
    title: 'Timeout intermitente no checkout',
    type: 'operacional',
    criticality: 'alta',
    description: 'P99 de latência subiu para 4.2s no serviço de pedidos desde segunda-feira.',
    action: 'Ativar cache de sessão e investigar query N+1 no ORM.',
    squad: 'alpha',
  },
  {
    title: 'Débito técnico acumulado em notificações',
    type: 'estrutural',
    criticality: 'media',
    description: 'Cobertura de testes abaixo de 40%. Múltiplos hotfixes nas últimas 4 semanas.',
    action: 'Reservar 20% da sprint para refactoring guiado.',
    squad: 'beta',
  },
  {
    title: 'Cota de API externa atingida',
    type: 'operacional',
    criticality: 'alta',
    description: 'Integração com serviço de CEP atingiu 100% da cota gratuita, causando erros silenciosos.',
    action: 'Migrar para plano pago ou trocar provedor até amanhã.',
    squad: 'gamma',
  },
  {
    title: 'Ausência de SLO definido para Auth',
    type: 'estrutural',
    criticality: 'baixa',
    description: 'Serviço crítico opera sem SLO formal, dificultando priorização de incidentes.',
    action: 'Incluir na próxima sprint de SRE Platform.',
    squad: 'delta',
  },
]

interface TeamMember {
  name: string
  role: string
  squad: Squad
  auto: number
  techLead: number
  skills: { skill: string; auto: number; techLead: number }[]
}

const teamMembers: TeamMember[] = [
  {
    name: 'João Ferreira', role: 'Engenheiro Sênior', squad: 'alpha', auto: 80, techLead: 75,
    skills: [
      { skill: 'Arquitetura', auto: 75, techLead: 70 },
      { skill: 'Qualidade', auto: 80, techLead: 78 },
      { skill: 'Entrega', auto: 85, techLead: 80 },
      { skill: 'Comunicação', auto: 70, techLead: 65 },
      { skill: 'Liderança', auto: 60, techLead: 62 },
      { skill: 'Segurança', auto: 72, techLead: 68 },
      { skill: 'Dados', auto: 65, techLead: 70 },
    ],
  },
  {
    name: 'Mariana Costa', role: 'Engenheira Pleno', squad: 'alpha', auto: 70, techLead: 74,
    skills: [
      { skill: 'Arquitetura', auto: 60, techLead: 65 },
      { skill: 'Qualidade', auto: 78, techLead: 80 },
      { skill: 'Entrega', auto: 72, techLead: 76 },
      { skill: 'Comunicação', auto: 80, techLead: 78 },
      { skill: 'Liderança', auto: 55, techLead: 58 },
      { skill: 'Segurança', auto: 65, techLead: 62 },
      { skill: 'Dados', auto: 68, techLead: 72 },
    ],
  },
  {
    name: 'Rafael Oliveira', role: 'Engenheiro Sênior', squad: 'beta', auto: 85, techLead: 78,
    skills: [
      { skill: 'Arquitetura', auto: 90, techLead: 82 },
      { skill: 'Qualidade', auto: 70, techLead: 65 },
      { skill: 'Entrega', auto: 88, techLead: 80 },
      { skill: 'Comunicação', auto: 75, techLead: 70 },
      { skill: 'Liderança', auto: 80, techLead: 76 },
      { skill: 'Segurança', auto: 85, techLead: 78 },
      { skill: 'Dados', auto: 90, techLead: 85 },
    ],
  },
  {
    name: 'Priscila Mendes', role: 'Engenheira Pleno', squad: 'gamma', auto: 65, techLead: 72,
    skills: [
      { skill: 'Arquitetura', auto: 55, techLead: 65 },
      { skill: 'Qualidade', auto: 75, techLead: 78 },
      { skill: 'Entrega', auto: 68, techLead: 74 },
      { skill: 'Comunicação', auto: 72, techLead: 75 },
      { skill: 'Liderança', auto: 50, techLead: 55 },
      { skill: 'Segurança', auto: 60, techLead: 65 },
      { skill: 'Dados', auto: 70, techLead: 73 },
    ],
  },
  {
    name: 'Thiago Nascimento', role: 'Engenheiro Sênior', squad: 'delta', auto: 72, techLead: 77,
    skills: [
      { skill: 'Arquitetura', auto: 78, techLead: 80 },
      { skill: 'Qualidade', auto: 65, techLead: 70 },
      { skill: 'Entrega', auto: 75, techLead: 78 },
      { skill: 'Comunicação', auto: 68, techLead: 72 },
      { skill: 'Liderança', auto: 70, techLead: 75 },
      { skill: 'Segurança', auto: 80, techLead: 82 },
      { skill: 'Dados', auto: 72, techLead: 76 },
    ],
  },
]

// ─── Config ──────────────────────────────────────────────────────────────────

type MetricRow = { label: string; value: number; unit: string; color: string }

const statusConfig = {
  saudavel: { label: 'Saudável', color: '#16A34A', bg: '#F0FDF4', border: '#BBF7D0', text: '#15803D' },
  atencao:  { label: 'Atenção',  color: '#D97706', bg: '#FFFBEB', border: '#FDE68A', text: '#B45309' },
  critico:  { label: 'Crítico',  color: '#DC2626', bg: '#FEF2F2', border: '#FECACA', text: '#B91C1C' },
}

const criticalityConfig = {
  alta:  { label: 'Alta',  color: '#DC2626', bg: '#FEF2F2', border: '#FECACA' },
  media: { label: 'Média', color: '#D97706', bg: '#FFFBEB', border: '#FDE68A' },
  baixa: { label: 'Baixa', color: '#2563EB', bg: '#EFF6FF', border: '#BFDBFE' },
}

// ─── Small components ────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: ProjectStatus }) {
  const cfg = statusConfig[status]
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold mono"
      style={{ color: cfg.text, background: cfg.bg, border: `1px solid ${cfg.border}` }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: cfg.color }} />
      {cfg.label}
    </span>
  )
}

function CriticalityBadge({ level }: { level: Criticality }) {
  const cfg = criticalityConfig[level]
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs mono font-medium"
      style={{ color: cfg.color, background: cfg.bg, border: `1px solid ${cfg.border}` }}
    >
      {cfg.label}
    </span>
  )
}

function TypeBadge({ type }: { type: IncidentType }) {
  const isOp = type === 'operacional'
  return (
    <span
      className="text-xs mono px-2 py-0.5 rounded"
      style={{
        color: isOp ? '#475569' : '#7C3AED',
        background: isOp ? '#F1F5F9' : '#F5F3FF',
        border: `1px solid ${isOp ? '#CBD5E1' : '#DDD6FE'}`,
      }}
    >
      {isOp ? 'Operacional' : 'Estrutural'}
    </span>
  )
}

function KpiCard({
  label, value, sub, color = '#1A2640',
}: {
  label: string; value: string | number; sub?: string; color?: string
}) {
  return (
    <div className="flex flex-col gap-2 p-5 rounded-xl bg-white" style={{ border: '1px solid #E2E8F0' }}>
      <span className="text-xs mono uppercase tracking-widest" style={{ color: '#94A3B8' }}>{label}</span>
      <span className="text-4xl font-bold mono leading-none" style={{ color }}>{value}</span>
      {sub && <span className="text-xs" style={{ color: '#94A3B8' }}>{sub}</span>}
    </div>
  )
}

function SquadFilter({ squad, setSquad }: { squad: Squad; setSquad: (s: Squad) => void }) {
  return (
    <div>
      <p className="text-xs mono uppercase tracking-widest mb-3" style={{ color: '#94A3B8' }}>Filtrar por Squad</p>
      <div className="flex gap-2 flex-wrap">
        {squads.map(s => (
          <button
            key={s.id}
            onClick={() => setSquad(s.id)}
            className="px-4 py-2 rounded-lg text-sm font-medium transition-all"
            style={{
              background: squad === s.id ? '#EFF6FF' : '#FFFFFF',
              color: squad === s.id ? '#2563EB' : '#64748B',
              border: `1px solid ${squad === s.id ? '#BFDBFE' : '#E2E8F0'}`,
            }}
          >
            {s.label}
          </button>
        ))}
      </div>
    </div>
  )
}

function GaugeBar({ value, max = 100, color }: { value: number; max?: number; color: string }) {
  return (
    <div className="relative h-2 rounded-full overflow-hidden" style={{ background: '#E2E8F0' }}>
      <div
        className="absolute left-0 top-0 h-full rounded-full transition-all duration-700"
        style={{ width: `${(value / max) * 100}%`, background: color }}
      />
    </div>
  )
}

// ─── Project Card ─────────────────────────────────────────────────────────────

function ProjectCard({ project }: { project: Project }) {
  const cfg = statusConfig[project.status]
  return (
    <div
      className="p-5 rounded-xl bg-white flex flex-col gap-4 transition-shadow duration-200 hover:shadow-md"
      style={{ border: '1px solid #E2E8F0' }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-base font-semibold leading-snug mb-1 truncate" style={{ color: '#1A2640' }}>
            {project.name}
          </h3>
          <p className="text-xs mono" style={{ color: '#94A3B8' }}>TL: {project.techLead}</p>
        </div>
        <StatusBadge status={project.status} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="p-3 rounded-lg" style={{ background: '#F8FAFC', border: '1px solid #E2E8F0' }}>
          <p className="text-xs mono mb-1" style={{ color: '#94A3B8' }}>Features em andamento</p>
          <p className="text-2xl font-bold mono" style={{ color: '#1A2640' }}>{project.features}</p>
        </div>
        <div className="p-3 rounded-lg" style={{ background: '#F8FAFC', border: '1px solid #E2E8F0' }}>
          <p className="text-xs mono mb-1" style={{ color: '#94A3B8' }}>Lead Time</p>
          <p className="text-2xl font-bold mono" style={{ color: cfg.color }}>{project.leadTime}</p>
        </div>
      </div>

      <div className="p-3 rounded-lg" style={{ background: cfg.bg, border: `1px solid ${cfg.border}` }}>
        <p className="text-xs mono uppercase tracking-wider mb-1" style={{ color: cfg.text }}>Status atual</p>
        <p className="text-xs leading-relaxed" style={{ color: '#475569' }}>{project.statusNote}</p>
      </div>

      <p className="text-sm leading-relaxed" style={{ color: '#64748B' }}>{project.summary}</p>

      <div
        className="flex items-start gap-2 p-3 rounded-lg"
        style={{ background: '#EFF6FF', border: '1px solid #BFDBFE' }}
      >
        <span className="text-xs mono shrink-0 font-semibold" style={{ color: '#2563EB' }}>→ Decisão</span>
        <p className="text-xs leading-relaxed" style={{ color: '#1D4ED8' }}>{project.nextDecision}</p>
      </div>
    </div>
  )
}

// ─── Incident Row ─────────────────────────────────────────────────────────────

function IncidentRow({ incident }: { incident: Incident }) {
  return (
    <div className="p-4 rounded-xl bg-white flex flex-col gap-2" style={{ border: '1px solid #E2E8F0' }}>
      <div className="flex items-center gap-2 flex-wrap">
        <CriticalityBadge level={incident.criticality} />
        <TypeBadge type={incident.type} />
        <span className="text-sm font-semibold" style={{ color: '#1A2640' }}>{incident.title}</span>
      </div>
      <p className="text-xs leading-relaxed" style={{ color: '#64748B' }}>{incident.description}</p>
      <div className="flex items-start gap-2 mt-1">
        <span className="text-xs mono shrink-0 font-semibold" style={{ color: '#D97706' }}>↗ Ação</span>
        <p className="text-xs" style={{ color: '#92400E' }}>{incident.action}</p>
      </div>
    </div>
  )
}

// ─── Indicators ──────────────────────────────────────────────────────────────

function AiConsumptionCard({ squad }: { squad: Squad }) {
  const allWeeks = ['S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8']
  const allValues: Record<Squad, number[]> = {
    todos:  [12, 18, 22, 19, 34, 41, 38, 52],
    alpha:  [5,  7,  8,  7, 12, 15, 14, 18],
    beta:   [3,  4,  6,  5,  9, 10,  9, 14],
    gamma:  [2,  4,  5,  4,  7,  9,  8, 12],
    delta:  [2,  3,  3,  3,  6,  7,  7,  8],
  }
  const values = allValues[squad]
  const max = Math.max(...values)
  const last = values[values.length - 1]
  const first = values[0]
  const change = Math.round(((last - first) / first) * 100)
  return (
    <div className="p-6 rounded-xl bg-white flex flex-col gap-5" style={{ border: '1px solid #E2E8F0' }}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs mono uppercase tracking-widest mb-1" style={{ color: '#94A3B8' }}>Consumo de IA no time</p>
          <p className="text-3xl font-bold mono" style={{ color: '#2563EB' }}>
            {last} <span className="text-base font-normal text-slate-400">interações/sem</span>
          </p>
        </div>
        <span className="text-xs mono px-2 py-1 rounded" style={{ background: '#F0FDF4', color: '#16A34A', border: '1px solid #BBF7D0' }}>
          +{change}% vs S1
        </span>
      </div>
      <div className="flex items-end gap-1.5 h-20">
        {values.map((v, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <div
              className="w-full rounded-t transition-all"
              style={{
                height: `${(v / max) * 64}px`,
                background: i === values.length - 1 ? '#2563EB' : '#E2E8F0',
              }}
            />
            <span className="text-xs mono" style={{ color: '#94A3B8', fontSize: '10px' }}>{allWeeks[i]}</span>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-3 gap-3">
        {[
          { tool: 'GitHub Copilot', pct: 68, color: '#2563EB' },
          { tool: 'Claude / GPT',   pct: 24, color: '#7C3AED' },
          { tool: 'Outros',         pct:  8, color: '#94A3B8' },
        ].map(({ tool, pct, color }) => (
          <div key={tool} className="flex flex-col gap-1.5">
            <div className="flex justify-between">
              <span className="text-xs" style={{ color: '#64748B' }}>{tool}</span>
              <span className="text-xs mono font-semibold" style={{ color }}>{pct}%</span>
            </div>
            <GaugeBar value={pct} color={color} />
          </div>
        ))}
      </div>
    </div>
  )
}

function SquadScoreCard({ squad }: { squad: Squad }) {
  const all = [
    { id: 'alpha', name: 'Alpha', score: 84, delta: +3 },
    { id: 'beta',  name: 'Beta',  score: 67, delta: -5 },
    { id: 'gamma', name: 'Gamma', score: 91, delta: +7 },
    { id: 'delta', name: 'Delta', score: 74, delta: +1 },
  ]
  const rows = squad === 'todos' ? all : all.filter(s => s.id === squad)
  const getColor = (s: number) => s >= 85 ? '#16A34A' : s >= 70 ? '#D97706' : '#DC2626'
  return (
    <div className="p-6 rounded-xl bg-white flex flex-col gap-5" style={{ border: '1px solid #E2E8F0' }}>
      <div>
        <p className="text-xs mono uppercase tracking-widest mb-1" style={{ color: '#94A3B8' }}>Score por Squad</p>
        <p className="text-xs" style={{ color: '#94A3B8' }}>Índice composto: entrega, qualidade, colaboração</p>
      </div>
      <div className="flex flex-col gap-4">
        {rows.map(({ name, score, delta }) => {
          const color = getColor(score)
          return (
            <div key={name} className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium" style={{ color: '#1A2640' }}>Squad {name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs mono font-semibold" style={{ color: delta > 0 ? '#16A34A' : '#DC2626' }}>
                    {delta > 0 ? '+' : ''}{delta}
                  </span>
                  <span className="text-xl font-bold mono" style={{ color }}>{score}</span>
                </div>
              </div>
              <GaugeBar value={score} color={color} />
            </div>
          )
        })}
      </div>
    </div>
  )
}

function CodeQualityCard({ squad }: { squad: Squad }) {
  const bySquad: Record<Squad, MetricRow[]> = {
    todos: [
      { label: 'Cobertura de Testes', value: 72,   unit: '%',    color: '#D97706' },
      { label: 'Bugs em Produção',    value: 8,    unit: 'abertos', color: '#DC2626' },
      { label: 'Dívida Técnica',      value: 14,   unit: 'dias',  color: '#D97706' },
      { label: 'Code Review Time',    value: 18,   unit: 'h avg', color: '#16A34A' },
      { label: 'Deploy Frequency',    value: 3.4,  unit: '/sem',  color: '#2563EB' },
      { label: 'MTTR',               value: 42,   unit: 'min',   color: '#16A34A' },
    ],
    alpha: [
      { label: 'Cobertura de Testes', value: 85,   unit: '%',    color: '#16A34A' },
      { label: 'Bugs em Produção',    value: 2,    unit: 'abertos', color: '#16A34A' },
      { label: 'Dívida Técnica',      value: 5,    unit: 'dias',  color: '#16A34A' },
      { label: 'Code Review Time',    value: 12,   unit: 'h avg', color: '#16A34A' },
      { label: 'Deploy Frequency',    value: 4.1,  unit: '/sem',  color: '#2563EB' },
      { label: 'MTTR',               value: 28,   unit: 'min',   color: '#16A34A' },
    ],
    beta: [
      { label: 'Cobertura de Testes', value: 38,   unit: '%',    color: '#DC2626' },
      { label: 'Bugs em Produção',    value: 14,   unit: 'abertos', color: '#DC2626' },
      { label: 'Dívida Técnica',      value: 32,   unit: 'dias',  color: '#DC2626' },
      { label: 'Code Review Time',    value: 24,   unit: 'h avg', color: '#DC2626' },
      { label: 'Deploy Frequency',    value: 1.8,  unit: '/sem',  color: '#D97706' },
      { label: 'MTTR',               value: 68,   unit: 'min',   color: '#D97706' },
    ],
    gamma: [
      { label: 'Cobertura de Testes', value: 91,   unit: '%',    color: '#16A34A' },
      { label: 'Bugs em Produção',    value: 1,    unit: 'abertos', color: '#16A34A' },
      { label: 'Dívida Técnica',      value: 4,    unit: 'dias',  color: '#16A34A' },
      { label: 'Code Review Time',    value: 10,   unit: 'h avg', color: '#16A34A' },
      { label: 'Deploy Frequency',    value: 5.2,  unit: '/sem',  color: '#2563EB' },
      { label: 'MTTR',               value: 18,   unit: 'min',   color: '#16A34A' },
    ],
    delta: [
      { label: 'Cobertura de Testes', value: 62,   unit: '%',    color: '#D97706' },
      { label: 'Bugs em Produção',    value: 5,    unit: 'abertos', color: '#D97706' },
      { label: 'Dívida Técnica',      value: 12,   unit: 'dias',  color: '#D97706' },
      { label: 'Code Review Time',    value: 20,   unit: 'h avg', color: '#D97706' },
      { label: 'Deploy Frequency',    value: 2.9,  unit: '/sem',  color: '#2563EB' },
      { label: 'MTTR',               value: 52,   unit: 'min',   color: '#D97706' },
    ],
  }
  const metrics = bySquad[squad]
  return (
    <div className="p-6 rounded-xl bg-white flex flex-col gap-5" style={{ border: '1px solid #E2E8F0' }}>
      <div>
        <p className="text-xs mono uppercase tracking-widest mb-1" style={{ color: '#94A3B8' }}>Qualidade de Código</p>
        <p className="text-xs" style={{ color: '#94A3B8' }}>Semana atual · SonarQube + Jira</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {metrics.map(({ label, value, unit, color }) => (
          <div key={label} className="flex flex-col gap-1 p-3 rounded-lg" style={{ background: '#F8FAFC', border: '1px solid #E2E8F0' }}>
            <span className="text-xs" style={{ color: '#94A3B8' }}>{label}</span>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold mono" style={{ color }}>{value}</span>
              <span className="text-xs mono" style={{ color: '#94A3B8' }}>{unit}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Main App ────────────────────────────────────────────────────────────────

export default function App() {
  const [tab, setTab] = useState<Tab>('projetos')
  const [squad, setSquad] = useState<Squad>('todos')
  const [selectedMember, setSelectedMember] = useState(0)

  const filteredProjects = squad === 'todos' ? projects : projects.filter(p => p.squad === squad)
  const filteredIncidents = squad === 'todos' ? incidents : incidents.filter(i => i.squad === squad)
  const filteredMembers = squad === 'todos' ? teamMembers : teamMembers.filter(m => m.squad === squad)

  const effectiveMember = filteredMembers[Math.min(selectedMember, filteredMembers.length - 1)]

  const now = new Date()
  const dateStr = now.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })

  const criticalCount = projects.filter(p => p.status === 'critico').length
  const highIncidents = incidents.filter(i => i.criticality === 'alta').length

  return (
    <div className="min-h-screen" style={{ background: '#F2F5FB' }}>
      {/* ── Header ── */}
      <header
        className="sticky top-0 z-50 px-6 py-4"
        style={{ background: 'rgba(242,245,251,0.92)', borderBottom: '1px solid #E2E8F0', backdropFilter: 'blur(12px)' }}
      >
        <div className="max-w-7xl mx-auto flex flex-col gap-3">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-1">
                <div className="w-2 h-2 rounded-full" style={{ background: '#16A34A' }} />
                <h1 className="text-xl font-bold tracking-tight" style={{ color: '#1A2640' }}>
                  Bate Semanal de Tech Leads
                </h1>
              </div>
              <p className="text-xs mono pl-5" style={{ color: '#94A3B8' }}>
                {dateStr} · Coordenação de Tecnologia
              </p>
            </div>
            <span className="text-xs mono px-3 py-1.5 rounded-lg" style={{ background: '#F0FDF4', color: '#16A34A', border: '1px solid #BBF7D0' }}>
              Semana 32 / 2026
            </span>
          </div>

          {/* Tabs */}
          <div className="flex gap-1">
            {([
              { id: 'projetos',    label: 'Projetos' },
              { id: 'indicadores', label: 'Indicadores' },
              { id: 'pessoas',     label: 'Pessoas' },
            ] as const).map(t => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className="px-5 py-2 rounded-lg text-sm font-medium transition-all duration-150"
                style={{
                  background: tab === t.id ? '#EFF6FF' : 'transparent',
                  color: tab === t.id ? '#2563EB' : '#64748B',
                  border: `1px solid ${tab === t.id ? '#BFDBFE' : 'transparent'}`,
                }}
              >
                {t.label}
                {t.id === 'pessoas' && (
                  <span className="ml-2 text-xs mono px-1.5 py-0.5 rounded" style={{ background: '#F5F3FF', color: '#7C3AED', border: '1px solid #DDD6FE' }}>
                    1×/mês
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">

        {/* ══ TAB: PROJETOS ══════════════════════════════════════════════════ */}
        {tab === 'projetos' && (
          <div className="flex flex-col gap-8">
            {/* KPIs */}
            <div className="grid grid-cols-4 gap-4">
              <KpiCard label="Projetos Ativos"     value={projects.length}  sub="em todos os squads" />
              <KpiCard label="Status Crítico"      value={criticalCount}    sub="requerem ação imediata" color="#DC2626" />
              <KpiCard label="Incidentes na Semana" value={highIncidents}   sub="criticidade alta" color="#D97706" />
              <KpiCard label="Pendências Críticas" value={7}                sub="aguardando decisão" color="#2563EB" />
            </div>

            <SquadFilter squad={squad} setSquad={setSquad} />

            {/* Projects */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <p className="text-xs mono uppercase tracking-widest" style={{ color: '#94A3B8' }}>
                  Projetos — {filteredProjects.length} exibidos
                </p>
                <div className="flex items-center gap-4">
                  {(['saudavel', 'atencao', 'critico'] as ProjectStatus[]).map(s => (
                    <span key={s} className="flex items-center gap-1.5 text-xs mono" style={{ color: statusConfig[s].text }}>
                      <span className="w-1.5 h-1.5 rounded-full" style={{ background: statusConfig[s].color }} />
                      {statusConfig[s].label}: {projects.filter(p => p.status === s).length}
                    </span>
                  ))}
                </div>
              </div>
              {filteredProjects.length === 0 ? (
                <div className="flex items-center justify-center h-32 rounded-xl bg-white" style={{ border: '1px solid #E2E8F0' }}>
                  <p className="text-sm" style={{ color: '#94A3B8' }}>Nenhum projeto neste squad</p>
                </div>
              ) : (
                <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))' }}>
                  {filteredProjects.map(p => <ProjectCard key={p.name} project={p} />)}
                </div>
              )}
            </div>

            {/* Incidents */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <p className="text-xs mono uppercase tracking-widest" style={{ color: '#94A3B8' }}>
                  Incidentes & Problemas — {filteredIncidents.length} ativos
                </p>
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1.5 text-xs mono" style={{ color: '#475569' }}>
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                    Operacional: {incidents.filter(i => i.type === 'operacional').length}
                  </span>
                  <span className="flex items-center gap-1.5 text-xs mono" style={{ color: '#7C3AED' }}>
                    <span className="w-1.5 h-1.5 rounded-full" style={{ background: '#7C3AED' }} />
                    Estrutural: {incidents.filter(i => i.type === 'estrutural').length}
                  </span>
                </div>
              </div>
              {filteredIncidents.length === 0 ? (
                <div className="flex items-center justify-center h-24 rounded-xl bg-white" style={{ border: '1px solid #E2E8F0' }}>
                  <p className="text-sm" style={{ color: '#94A3B8' }}>Nenhum incidente neste squad</p>
                </div>
              ) : (
                <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(380px, 1fr))' }}>
                  {filteredIncidents.map(i => <IncidentRow key={i.title} incident={i} />)}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ══ TAB: INDICADORES ══════════════════════════════════════════════ */}
        {tab === 'indicadores' && (
          <div className="flex flex-col gap-8">
            <SquadFilter squad={squad} setSquad={setSquad} />

            <div className="grid gap-6" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(380px, 1fr))' }}>
              <AiConsumptionCard squad={squad} />
              <SquadScoreCard squad={squad} />
              <CodeQualityCard squad={squad} />
            </div>

            {/* DORA strip */}
            <div>
              <p className="text-xs mono uppercase tracking-widest mb-4" style={{ color: '#94A3B8' }}>
                DORA Metrics — Semana atual
              </p>
              <div className="grid grid-cols-4 gap-4">
                {[
                  { label: 'Deploy Frequency',    value: '3.4/sem', color: '#16A34A' },
                  { label: 'Lead Time p/ Change', value: '6.2 dias', color: '#D97706' },
                  { label: 'Change Failure Rate', value: '8.3%',   color: '#D97706' },
                  { label: 'MTTR',               value: '42 min',  color: '#16A34A' },
                ].map(({ label, value, color }) => (
                  <div key={label} className="p-4 rounded-xl bg-white" style={{ border: '1px solid #E2E8F0' }}>
                    <p className="text-xs mono uppercase tracking-widest mb-3" style={{ color: '#94A3B8' }}>{label}</p>
                    <p className="text-2xl font-bold mono" style={{ color }}>{value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ══ TAB: PESSOAS ══════════════════════════════════════════════════ */}
        {tab === 'pessoas' && (
          <div className="flex flex-col gap-6">
            <div
              className="flex items-center gap-3 px-4 py-3 rounded-xl"
              style={{ background: '#F5F3FF', border: '1px solid #DDD6FE' }}
            >
              <span className="text-base">📅</span>
              <p className="text-sm" style={{ color: '#6D28D9' }}>
                Esta aba é revisada <strong>1× por mês</strong> — autoavaliação dos membros + avaliação do Tech Lead para cada pessoa do time.
              </p>
            </div>

            <SquadFilter squad={squad} setSquad={(s) => { setSquad(s); setSelectedMember(0) }} />

            {filteredMembers.length === 0 ? (
              <div className="flex items-center justify-center h-32 rounded-xl bg-white" style={{ border: '1px solid #E2E8F0' }}>
                <p className="text-sm" style={{ color: '#94A3B8' }}>Nenhum membro neste squad</p>
              </div>
            ) : (
              <div className="grid gap-6" style={{ gridTemplateColumns: '260px 1fr' }}>
                {/* Member list */}
                <div className="flex flex-col gap-2">
                  <p className="text-xs mono uppercase tracking-widest mb-1" style={{ color: '#94A3B8' }}>
                    Membros do time
                  </p>
                  {filteredMembers.map((m, i) => {
                    const isSelected = effectiveMember?.name === m.name
                    const gap = m.auto - m.techLead
                    return (
                      <button
                        key={m.name}
                        onClick={() => setSelectedMember(i)}
                        className="w-full text-left p-3 rounded-xl transition-all"
                        style={{
                          background: isSelected ? '#EFF6FF' : '#FFFFFF',
                          border: `1px solid ${isSelected ? '#BFDBFE' : '#E2E8F0'}`,
                        }}
                      >
                        <p className="text-sm font-semibold" style={{ color: '#1A2640' }}>{m.name}</p>
                        <p className="text-xs mono" style={{ color: '#94A3B8' }}>{m.role} · {m.squad.charAt(0).toUpperCase() + m.squad.slice(1)}</p>
                        <div className="flex gap-3 mt-2">
                          <span className="text-xs mono" style={{ color: '#16A34A' }}>Auto: {m.auto}</span>
                          <span className="text-xs mono" style={{ color: '#2563EB' }}>TL: {m.techLead}</span>
                          <span className="text-xs mono" style={{ color: gap > 0 ? '#D97706' : '#94A3B8' }}>
                            {gap > 0 ? `+${gap} gap` : gap < 0 ? `${gap} gap` : 'alinhado'}
                          </span>
                        </div>
                      </button>
                    )
                  })}
                </div>

                {/* Radar */}
                {effectiveMember && (
                  <div className="p-6 rounded-xl bg-white flex flex-col gap-6" style={{ border: '1px solid #E2E8F0' }}>
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-xs mono uppercase tracking-widest mb-1" style={{ color: '#94A3B8' }}>
                          Mapa de Competências
                        </p>
                        <p className="text-lg font-semibold" style={{ color: '#1A2640' }}>{effectiveMember.name}</p>
                        <p className="text-xs mono" style={{ color: '#94A3B8' }}>
                          {effectiveMember.role} · Squad {effectiveMember.squad.charAt(0).toUpperCase() + effectiveMember.squad.slice(1)}
                        </p>
                      </div>
                      <div className="flex gap-5 text-xs mono">
                        <span className="flex items-center gap-2" style={{ color: '#16A34A' }}>
                          <span className="inline-block w-4 h-0.5 rounded" style={{ background: '#16A34A' }} />
                          Autoavaliação
                        </span>
                        <span className="flex items-center gap-2" style={{ color: '#2563EB' }}>
                          <span className="inline-block w-4 border-t-2 border-dashed" style={{ borderColor: '#2563EB' }} />
                          Tech Lead
                        </span>
                      </div>
                    </div>

                    <ResponsiveContainer width="100%" height={340}>
                      <RadarChart data={effectiveMember.skills} margin={{ top: 10, right: 30, bottom: 10, left: 30 }}>
                        <PolarGrid stroke="#E2E8F0" />
                        <PolarAngleAxis
                          dataKey="skill"
                          tick={{ fill: '#64748B', fontSize: 12, fontFamily: 'JetBrains Mono' }}
                        />
                        <PolarRadiusAxis
                          angle={30}
                          domain={[0, 100]}
                          tick={{ fill: '#94A3B8', fontSize: 10, fontFamily: 'JetBrains Mono' }}
                          stroke="#E2E8F0"
                        />
                        <Radar
                          name="Autoavaliação"
                          dataKey="auto"
                          stroke="#16A34A"
                          fill="#16A34A"
                          fillOpacity={0.15}
                          strokeWidth={2}
                        />
                        <Radar
                          name="Tech Lead"
                          dataKey="techLead"
                          stroke="#2563EB"
                          fill="#2563EB"
                          fillOpacity={0.08}
                          strokeWidth={2}
                          strokeDasharray="4 2"
                        />
                        <Tooltip
                          contentStyle={{
                            background: '#FFFFFF',
                            border: '1px solid #E2E8F0',
                            borderRadius: 8,
                            color: '#1A2640',
                            fontFamily: 'JetBrains Mono',
                            fontSize: 12,
                            boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                          }}
                        />
                        <Legend wrapperStyle={{ fontFamily: 'JetBrains Mono', fontSize: 12, color: '#64748B' }} />
                      </RadarChart>
                    </ResponsiveContainer>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl text-center" style={{ background: '#F0FDF4', border: '1px solid #BBF7D0' }}>
                        <p className="text-xs mono mb-1" style={{ color: '#94A3B8' }}>Score Autoavaliação</p>
                        <p className="text-3xl font-bold mono" style={{ color: '#16A34A' }}>{effectiveMember.auto}</p>
                      </div>
                      <div className="p-4 rounded-xl text-center" style={{ background: '#EFF6FF', border: '1px solid #BFDBFE' }}>
                        <p className="text-xs mono mb-1" style={{ color: '#94A3B8' }}>Score Tech Lead</p>
                        <p className="text-3xl font-bold mono" style={{ color: '#2563EB' }}>{effectiveMember.techLead}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-12 px-6 py-4" style={{ borderTop: '1px solid #E2E8F0' }}>
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <p className="text-xs mono" style={{ color: '#94A3B8' }}>Bate Semanal de Tech Leads · Coordenação de Tecnologia</p>
          <p className="text-xs mono" style={{ color: '#94A3B8' }}>Dados: Jira · SonarQube · GitHub · Copilot Analytics</p>
        </div>
      </footer>
    </div>
  )
}

